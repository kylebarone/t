# HashiCorp Senior Solutions Engineer - Quick Reference

## Pre-Interview Checklist

✓ Review the company's tech stack (LinkedIn, job description)
✓ Research their industry's compliance requirements
✓ Prepare 2-3 questions about their product/architecture
✓ Have examples ready of similar customer wins
✓ Bring diagrams (printed or on tablet)
✓ Test your screen sharing setup

---

## 30-Second Elevator Pitches

### Terraform
"Terraform is infrastructure as code that lets you define cloud resources in simple config files. Instead of clicking through AWS console for hours, you write code once and provision consistently across dev, staging, and production. The result? Faster deployments, no configuration drift, and complete audit trails. Companies go from weeks to minutes for new environments."

### Vault
"Vault is secrets management done right. Instead of hardcoding database passwords or storing them in environment variables, applications authenticate to Vault and get short-lived, dynamic credentials that expire automatically. Every secret access is audited. The result? Pass security audits, prevent breaches, and sleep better at night knowing credentials rotate automatically."

### Terraform + Vault Together
"Terraform provisions the infrastructure while Vault secures it. Terraform can retrieve secrets from Vault, ensuring no credentials ever live in your code or state files. Together, they provide infrastructure automation with enterprise-grade security built in."

---

## HashiCorp Product Portfolio (Quick Summary)

| Product | Purpose | One-Liner |
|---------|---------|-----------|
| **Terraform** | Infrastructure as Code | Provision and manage cloud infrastructure |
| **Vault** | Secrets Management | Secure, store, and tightly control access to secrets |
| **Consul** | Service Networking | Service discovery and service mesh |
| **Nomad** | Workload Orchestration | Deploy and manage applications (container & non-container) |
| **Boundary** | Secure Remote Access | Identity-based infrastructure access |
| **Waypoint** | Application Deployment | Build, deploy, and release across platforms |
| **Packer** | Image Building | Create machine images for multiple platforms |

**Key Integrations:**
- Terraform + Vault = Secure IaC
- Terraform + Consul = Service discovery automation
- Terraform + Packer = Complete CI/CD for infrastructure
- Vault + Kubernetes = Dynamic credentials for pods

---

## Common Client Personas & Their Pain Points

### CISO / Security Leader
**Pain:** Credential sprawl, audit failures, breach risk
**Solution:** Vault (dynamic secrets, audit logging, encryption)
**Value Prop:** "Pass audits automatically, reduce breach risk"

### VP Engineering / CTO
**Pain:** Slow provisioning, inconsistent environments, developer bottlenecks
**Solution:** Terraform Cloud + Self-service
**Value Prop:** "10x faster infrastructure, enable developer velocity"

### Platform / Infrastructure Team
**Pain:** Manual toil, configuration drift, multi-cloud complexity
**Solution:** Terraform + Modules + Policies
**Value Prop:** "Automate the mundane, focus on architecture"

### Compliance Officer
**Pain:** Audit prep, policy enforcement, documentation
**Solution:** Sentinel + Audit logs + IaC documentation
**Value Prop:** "Compliance as code, audit-ready instantly"

### CFO / Finance
**Pain:** Cloud cost overruns, no visibility, waste
**Solution:** Terraform Cloud cost estimation + Tags
**Value Prop:** "30% cost reduction through right-sizing and auto-shutdown"

---

## Discovery Questions (SPIN Framework)

### Situation (Current State)
- "How do you provision infrastructure today?"
- "What tools are you currently using?"
- "Who manages production infrastructure?"

### Problem (Pain Points)
- "What's your biggest infrastructure challenge?"
- "How long does provisioning take?"
- "Have you had security incidents?"

### Implication (Make Pain Real)
- "How does slow provisioning affect time to market?"
- "What's the business cost of downtime?"
- "What happens if audit findings aren't resolved?"

### Need-Payoff (Show Value)
- "What if you could provision in minutes, not weeks?"
- "How would automatic compliance help?"
- "What could your team focus on if this was automated?"

---

## Key Technical Concepts (30 Seconds Each)

### Infrastructure as Code (IaC)
"Manage infrastructure through code instead of manual processes. Version control for servers. Same code = same infrastructure every time."

### State Management
"Terraform tracks real-world resources in a state file - the source of truth. Enables drift detection and safe changes."

### Dynamic Secrets
"Vault generates temporary credentials on-demand. Unlike static passwords that live forever, these expire automatically - reducing blast radius if compromised."

### Policy as Code (Sentinel)
"Define compliance rules in code. Prevents violations before they happen - like spell-check for infrastructure."

### Modules
"Reusable infrastructure components. Like functions in programming - write once, use everywhere with different parameters."

---

## Enterprise Features (Why Upgrade from Open Source)

### Terraform Enterprise/Cloud
- **Sentinel Policies:** Compliance as code
- **Private Module Registry:** Internal standards
- **Cost Estimation:** Pre-deployment cost visibility
- **SSO & RBAC:** Team access control
- **Audit Logging:** Complete change history
- **VCS Integration:** GitOps workflow

**ROI Pitch:** "Open source gets you IaC. Enterprise gets you governance, collaboration, and compliance at scale."

### Vault Enterprise
- **Namespaces:** Multi-tenancy
- **Replication:** DR & performance replication
- **HSM Support:** Hardware security modules
- **Sentinel:** Policy enforcement
- **MFA:** Additional auth layer
- **24/7 Support:** Enterprise SLAs

**ROI Pitch:** "Open source secures secrets. Enterprise adds disaster recovery, scalability, and compliance features."

---

## Value Propositions by Use Case

### Multi-Cloud
**Before:** Different tools per cloud, no consistency
**After:** Single workflow across AWS, Azure, GCP
**ROI:** Reduced tool sprawl, faster multi-cloud deployment

### Security & Compliance
**Before:** Static credentials, no audit trail
**After:** Dynamic secrets, complete logging
**ROI:** Pass audits, reduce breach risk

### Speed & Agility
**Before:** Weeks to provision, manual processes
**After:** Minutes to provision, self-service
**ROI:** 10x faster, developer productivity

### Cost Optimization
**Before:** Over-provisioned, always-on resources
**After:** Right-sized, auto-scaled, auto-shutdown
**ROI:** 20-40% cloud cost reduction

---

## Objection Handling (Quick Responses)

**"Too expensive"**
→ "Let's look at ROI: What did last outage cost? What's engineer time worth? Enterprise pays for itself in 6-9 months for most customers."

**"Too complex"**
→ "Complexity exists either way. Question is: hidden in manual processes or explicit in reviewable code? We provide training and start small."

**"Already using CloudFormation"**
→ "CF is great for AWS-only. When you expand to Azure or GCP, you'll need another tool. Terraform works everywhere from day one."

**"Vendor lock-in concerns"**
→ "Terraform is open source. Your code is portable. We actually reduce cloud vendor lock-in by working across all providers."

**"Not ready for Enterprise"**
→ "Start with open source. Upgrade when you need governance, compliance, or scale. Many customers run OSS in production."

---

## Architecture Patterns (Diagrams to Draw)

### 3-Tier Web Application
```
┌──────────────┐
│   Route 53   │ (DNS)
└──────┬───────┘
       │
┌──────▼───────┐
│ CloudFront   │ (CDN)
└──────┬───────┘
       │
┌──────▼───────┐
│     ALB      │ (Load Balancer)
└──────┬───────┘
       │
   ┌───┴───┐
   │  ASG  │ (Auto-scaling compute)
   └───┬───┘
       │
   ┌───▼───┐
   │  RDS  │ (Database Multi-AZ)
   └───────┘
```

### Multi-Environment Strategy
```
Git Repo
   ├── main branch → Production
   ├── staging branch → Staging  
   └── develop branch → Dev

Each environment:
   - Separate state file
   - Separate workspace
   - Same modules, different vars
```

### Vault Architecture
```
Applications
      │
      ├─── Authenticate
      │
      ▼
  ┌────────┐
  │ Vault  │
  │ Cluster│
  └───┬────┘
      │
      ├─── Dynamic DB Creds
      ├─── Cloud API Keys
      └─── Encryption Keys
```

---

## Red Flags to Watch For

### Client Red Flags
- Expecting magic overnight (set realistic timelines)
- Resistance to change (cultural challenges)
- No buy-in from security team (need all stakeholders)
- Unrealistic budget (be honest about costs)
- "Just want a demo" (qualify the opportunity)

### Technical Red Flags
- Legacy apps that can't be automated (scope carefully)
- Highly customized, snowflake infrastructure (education needed)
- No version control (basic maturity lacking)
- Ad-hoc security everywhere (vault can help but needs commitment)

---

## Success Metrics to Discuss

### Time Metrics
- Provisioning time: X weeks → Y minutes
- Time to recovery: X hours → Y minutes
- Developer wait time: X days → Y minutes

### Quality Metrics
- Configuration drift: X% → 0%
- Failed audits: X → 0
- Security incidents: X → Y

### Business Metrics
- Cost reduction: X%
- Developer productivity: X%
- Time to market: X% faster
- Audit prep time: X weeks → Y days

---

## Key Statistics to Remember

- **90%** faster provisioning (typical)
- **40%** cost reduction (with right-sizing)
- **10x** return on investment (enterprise features)
- **3,000+** Terraform providers
- **100+** Fortune 500 companies use HashiCorp

---

## Your Differentiators (Why HashiCorp?)

1. **Multi-cloud from day one** (not an afterthought)
2. **10+ years of production hardening** (mature, stable)
3. **Largest community** (3,000+ providers, millions of users)
4. **Open source foundation** (transparency, no lock-in)
5. **Complete platform** (Terraform + Vault + Consul + more)
6. **Proven at scale** (Fortune 500 trust us)

---

## Interview Day Reminders

### Before
- [ ] Review their website/products
- [ ] Check their tech stack (job posts, blog)
- [ ] Prepare relevant customer stories
- [ ] Test your examples/demos

### During
- [ ] Listen 70%, talk 30%
- [ ] Ask clarifying questions
- [ ] Lead with business value
- [ ] Draw diagrams
- [ ] Give specific examples
- [ ] Be honest about limitations

### After
- [ ] Send thank you + relevant resources
- [ ] Answer any outstanding questions
- [ ] Propose clear next steps
- [ ] Follow up timeline

---

## Sample Questions They Might Ask You

**"Tell me about yourself"**
→ Brief background + why HashiCorp excites you + relevant experience

**"Why HashiCorp?"**
→ Product quality + technical depth + industry impact + growth opportunity

**"Describe a difficult client situation"**
→ Use STAR: Situation, Task, Action, Result

**"How do you handle objections?"**
→ Listen, acknowledge, ask questions, provide specific examples/data

**"What's your experience with [specific tech]?"**
→ Be honest. If you don't know it, explain how you'd learn + transfer similar experience

---

## Your Questions to Ask Them

1. "What does success look like for this role in the first 90 days?"
2. "Can you describe a recent deal cycle and how solutions engineering contributed?"
3. "How does SE collaborate with sales and product teams?"
4. "What are the biggest technical challenges your customers face?"
5. "How does HashiCorp support SE growth and development?"
6. "What do you love about working at HashiCorp?"

---

## Final Confidence Builders

✓ You understand the technical fundamentals
✓ You know the products and their value
✓ You can articulate business outcomes
✓ You have frameworks for discovery
✓ You can handle objections professionally
✓ You're prepared to learn what you don't know

**Remember:**
- Solutions engineering is about listening and solving problems
- It's OK to say "I don't know, let me research that"
- Business value > technical features
- You're selling outcomes, not software
- Be yourself - authenticity matters

---

## Emergency Phone-a-Friend Topics

If stuck on a question, bridge to what you DO know:

**Don't know specific tech?**
→ "I haven't worked with that directly, but based on my understanding of [similar tech], I'd approach it by..."

**Don't know industry?**
→ "What are the specific regulatory requirements you face? I want to ensure I'm addressing the right compliance concerns..."

**Don't know answer?**
→ "That's a great question. Let me think through the implications... [reason out loud] ...and I'd want to research [X] to give you a complete answer."

**Shows:** Problem-solving, honesty, and methodology > memorized answers

---

## Last-Minute Review (15 Minutes Before)

1. **Breathe** - You've got this
2. **Skim** this cheat sheet one more time
3. **Pull up** HashiCorp website in a tab
4. **Review** their company info
5. **Prepare** your "Tell me about yourself"
6. **Smile** - Enthusiasm is contagious

**Good luck! 🚀**

