# HashiCorp Vault: Secrets Management & Security

## What is Vault?

**HashiCorp Vault** is a secrets management and data protection platform that provides:
- Centralized secrets storage
- Dynamic secrets generation
- Data encryption services
- Identity-based access
- Audit logging

**Think of it as:** A secure vault for all sensitive data with fine-grained access control and complete audit trails.

---

## Core Concepts

### 1. Secrets Engines

Vault uses "secrets engines" to store, generate, or encrypt data. Different types for different needs:

**Static Secrets (Key-Value):**
```hcl
# Store API keys, passwords, certificates
vault kv put secret/app/database \
  username=admin \
  password=supersecret
```

**Dynamic Secrets:**
- **Database Credentials:** Generate temporary DB credentials on-demand
- **Cloud Credentials:** Temporary AWS/Azure/GCP credentials
- **SSH Keys:** Short-lived SSH credentials

**Why Dynamic Secrets Matter:**
- Credentials expire automatically
- Unique credentials per consumer
- Automatic rotation
- Reduced blast radius if compromised

### 2. Authentication Methods

**How systems/users prove identity to Vault:**

- **Kubernetes Auth** - Pods authenticate with service account tokens
- **AWS IAM** - EC2 instances authenticate with IAM roles
- **Azure AD** - Azure resources authenticate with managed identities
- **LDAP/Active Directory** - User authentication
- **AppRole** - Application authentication
- **JWT/OIDC** - Token-based auth
- **TLS Certificates** - Certificate-based auth

### 3. Policies

**Define who can access what:**
```hcl
# Example policy
path "secret/data/app/*" {
  capabilities = ["read", "list"]
}

path "database/creds/readonly" {
  capabilities = ["read"]
}
```

**Least privilege principle:** Grant only necessary permissions.

### 4. Audit Logging

**Complete audit trail:**
- Who accessed what?
- When?
- What was the result?
- Immutable logs for compliance

---

## Terraform + Vault Integration

### Pattern 1: Vault Provider in Terraform

**Use Vault to store Terraform secrets:**

```hcl
# Configure Vault provider
provider "vault" {
  address = "https://vault.company.com"
}

# Read secrets from Vault
data "vault_generic_secret" "db_creds" {
  path = "secret/database/prod"
}

# Use in Terraform resources
resource "aws_db_instance" "main" {
  username = data.vault_generic_secret.db_creds.data["username"]
  password = data.vault_generic_secret.db_creds.data["password"]
  # ... other config
}
```

**Benefits:**
- No hardcoded secrets in Terraform
- Secrets never in state file (only references)
- Centralized secret rotation
- Audit trail of secret access

### Pattern 2: Dynamic Database Credentials

**Vault generates temporary DB credentials:**

```hcl
# Configure database secrets engine
resource "vault_database_secrets_mount" "db" {
  path = "database"

  postgresql {
    name              = "prod-db"
    connection_url    = "postgresql://{{username}}:{{password}}@postgres:5432/mydb"
    username          = data.vault_generic_secret.db_admin.data["username"]
    password          = data.vault_generic_secret.db_admin.data["password"]
    allowed_roles     = ["readonly", "readwrite"]
  }
}

# Define role for read-only access
resource "vault_database_secret_backend_role" "readonly" {
  name    = "readonly"
  db_name = vault_database_secrets_mount.db.postgresql[0].name
  creation_statements = [
    "CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}';",
    "GRANT SELECT ON ALL TABLES IN SCHEMA public TO \"{{name}}\";"
  ]
  default_ttl = 3600      # 1 hour
  max_ttl     = 86400     # 24 hours
}
```

**Application retrieves credentials:**
```bash
# App requests credentials
vault read database/creds/readonly

# Vault creates a temporary user in the database
# Returns credentials that expire in 1 hour
# After expiration, Vault revokes the credentials
```

**Client Value:**
- No long-lived credentials
- Automatic credential rotation
- Reduced risk if leaked
- Compliance with zero-trust security

### Pattern 3: Cloud Credentials

**Dynamic AWS credentials:**

```hcl
# AWS secrets engine
resource "vault_aws_secret_backend" "aws" {
  path = "aws"
  access_key = var.aws_admin_access_key
  secret_key = var.aws_admin_secret_key
}

# Define role with specific permissions
resource "vault_aws_secret_backend_role" "developer" {
  backend = vault_aws_secret_backend.aws.path
  name    = "developer-role"
  credential_type = "iam_user"

  policy_document = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ec2:Describe*",
          "s3:ListBucket",
          "s3:GetObject"
        ]
        Resource = "*"
      }
    ]
  })
}
```

**Developers get temporary AWS credentials:**
- Short-lived (default 1 hour)
- Scoped to specific permissions
- Automatically revoked

---

## Encryption as a Service (Transit Engine)

**Vault encrypts/decrypts data without storing it:**

```hcl
# Enable transit engine
resource "vault_mount" "transit" {
  path = "transit"
  type = "transit"
}

# Create encryption key
resource "vault_transit_secret_backend_key" "key" {
  backend = vault_mount.transit.path
  name    = "app-encryption-key"
}
```

**Application uses Vault for encryption:**
```bash
# Encrypt data
vault write transit/encrypt/app-encryption-key \
  plaintext=$(base64 <<< "sensitive data")

# Returns encrypted ciphertext
# Vault never stores the plaintext

# Decrypt data
vault write transit/decrypt/app-encryption-key \
  ciphertext=vault:v1:abc123...
```

**Use Cases:**
- PCI DSS compliance (credit card data)
- HIPAA compliance (PHI data)
- GDPR compliance (personal data)
- Application-level encryption

**Benefits:**
- Centralized key management
- Key rotation without re-encrypting data
- Audit all encrypt/decrypt operations
- No need to manage encryption keys in app

---

## Enterprise Architecture Patterns

### Pattern 1: Vault HA Cluster

**Production Setup:**
```
                    Load Balancer
                         |
        +----------------+----------------+
        |                |                |
    Vault Node 1    Vault Node 2    Vault Node 3
    (Active)        (Standby)       (Standby)
        |                |                |
        +----------------+----------------+
                         |
                   Storage Backend
               (Consul, S3, Azure Storage)
```

**Key Features:**
- High availability with automatic failover
- Integrated storage or external (Consul recommended)
- Auto-unsealing with cloud KMS
- Performance standbys for read scaling

### Pattern 2: Multi-Region Vault

**For global enterprises:**
- Performance replication (read-only replicas)
- Disaster recovery replication (full failover capability)
- Reduced latency for global teams
- Business continuity

### Pattern 3: Namespaces (Vault Enterprise)

**Multi-tenancy:**
```
Vault
├── namespace: team-a
│   ├── auth/
│   ├── secret/
│   └── policy/
├── namespace: team-b
│   ├── auth/
│   ├── secret/
│   └── policy/
└── namespace: team-c
```

**Benefits:**
- Isolated environments for teams/projects
- Delegated administration
- Separate audit logs
- Prevents cross-team access

---

## Security Best Practices

### 1. Seal/Unseal Process

**Vault starts "sealed" (encrypted):**
- Requires unseal keys to decrypt
- Shamir secret sharing (5 keys, need 3 to unseal)
- Auto-unseal with cloud KMS (production recommended)

### 2. Root Token Management

**Root token = master key:**
- Generate only when needed
- Revoke immediately after use
- Never store long-term
- Break-glass procedures

### 3. Least Privilege Access

**Policy design:**
- Grant minimum necessary permissions
- Use policy templates
- Regular policy audits
- Time-bound tokens

### 4. Audit Logging

**Enable multiple audit devices:**
- File audit device
- Syslog audit device
- Cloud logging (CloudWatch, Stackdriver)
- Immutable audit trail

---

## Client Use Cases & Solutions

### Use Case 1: "We have secrets in GitHub"
**Problem:** Hardcoded credentials in code
**Solution:**
1. Move all secrets to Vault
2. Applications authenticate to Vault (AppRole, K8s auth)
3. Retrieve secrets at runtime
4. Implement dynamic secrets where possible

**ROI:**
- Eliminate credential leaks
- Pass security audits
- Faster incident response
- Automated rotation

### Use Case 2: "Database password sharing is a nightmare"
**Problem:** Shared database passwords, no audit trail
**Solution:**
1. Enable database secrets engine
2. Define roles per access level
3. Users/apps request temporary credentials
4. Complete audit trail

**Benefits:**
- Individual accountability
- Automatic rotation
- Easy revocation
- Compliance ready

### Use Case 3: "We need to encrypt PII data"
**Problem:** Application needs to encrypt sensitive data, GDPR compliance
**Solution:**
1. Enable Transit secrets engine
2. Application sends data to Vault for encryption
3. Vault returns ciphertext
4. Store ciphertext in database
5. Decrypt on read through Vault

**Benefits:**
- Centralized key management
- Audit all access
- Key rotation without data migration
- Compliance evidence

### Use Case 4: "Multi-cloud credential management"
**Problem:** Managing credentials across AWS, Azure, GCP
**Solution:**
1. Enable cloud secrets engines for each provider
2. Define roles with specific permissions
3. Developers request temporary cloud credentials
4. Credentials auto-expire

**Benefits:**
- Unified credential management
- Reduced attack surface
- Better cloud cost tracking (per-user creds)
- Cross-cloud consistency

---

## Vault + Terraform Cloud/Enterprise

**Integrated Workflow:**

```hcl
# Terraform Cloud workspace uses Vault for secrets
# Configure via workspace settings, not code
# Terraform automatically authenticates to Vault
# Retrieves secrets during plan/apply

data "vault_generic_secret" "api_keys" {
  path = "secret/terraform/prod"
}

resource "datadog_monitor" "api" {
  api_key = data.vault_generic_secret.api_keys.data["datadog_api_key"]
  app_key = data.vault_generic_secret.api_keys.data["datadog_app_key"]
  # ...
}
```

**Benefits:**
- No secrets in Terraform Cloud
- Vault audit logs track Terraform's secret access
- Centralized secret management
- Works with Sentinel policies

---

## Vault Adoption Journey

### Phase 1: Static Secrets (Weeks 1-2)
- Deploy Vault (HA cluster)
- Migrate static secrets from code/config
- Set up basic authentication
- Enable audit logging

**Quick Win:** Eliminate hardcoded secrets

### Phase 2: Dynamic Secrets (Weeks 3-6)
- Enable database secrets engine
- Implement dynamic DB credentials for apps
- Set up cloud provider secrets engines
- Tune TTLs and policies

**Impact:** Automated credential rotation

### Phase 3: Encryption Services (Weeks 7-10)
- Enable Transit engine
- Integrate encryption in applications
- Implement data tokenization
- Key rotation strategies

**Impact:** Compliance ready

### Phase 4: Advanced Features (Ongoing)
- Namespaces for multi-tenancy
- Performance replication for scale
- DR replication for resilience
- Sentinel policies for governance

---

## Comparison: Vault vs Alternatives

### vs AWS Secrets Manager
**Vault Advantages:**
- Multi-cloud (not locked to AWS)
- Dynamic secrets
- Encryption as a service
- More flexible policies
- HashiCorp ecosystem integration

**When AWS Secrets Manager:** AWS-only, simple rotation needs

### vs Azure Key Vault
**Vault Advantages:**
- Multi-cloud
- Broader secrets engine support
- Dynamic credentials
- Better audit capabilities

**When Azure Key Vault:** Azure-only, certificate management focus

### vs Kubernetes Secrets
**Vault Advantages:**
- Encryption at rest (K8s secrets base64 only)
- Dynamic secrets
- Audit logging
- Fine-grained access control
- External secret management

**When K8s Secrets:** Simple, ephemeral secrets within cluster only

---

## Key Metrics for Client Success

### Security Posture
- **Before Vault:** Secrets in 50+ locations (code, config, wikis)
- **After Vault:** Single source of truth, encrypted, audited

### Compliance
- **Audit Readiness:** Minutes (Vault audit logs) vs weeks (manual investigation)
- **Credential Rotation:** Automatic vs manual (quarterly if lucky)

### Incident Response
- **Time to Revoke:** Seconds (Vault API) vs hours/days (manual password changes)
- **Blast Radius:** Single credential vs shared passwords

### Developer Productivity
- **Credential Requests:** Self-service vs ticketing system
- **Onboarding Time:** Automated access vs manual provisioning

---

## Interview Talking Points

### Technical Depth
- "How does Shamir secret sharing work?"
- "Explain the seal/unseal process"
- "How would you design a Vault HA cluster?"
- "What's the difference between performance and DR replication?"

### Solution Focus
- "Walk me through solving [client scenario]"
- "How would you migrate from AWS Secrets Manager?"
- "Design a Vault architecture for a multi-cloud environment"
- "How does Vault integrate with Terraform Cloud?"

### Business Value
- "What's the ROI of Vault?"
- "How does Vault help with compliance?"
- "What's the total cost of ownership?"
- "How do you measure success after Vault deployment?"

---

## Quick Reference Commands

```bash
# Start Vault server
vault server -dev

# Unseal Vault
vault operator unseal <key>

# Write secret
vault kv put secret/myapp/config api_key=abc123

# Read secret
vault kv get secret/myapp/config

# Dynamic DB credentials
vault read database/creds/my-role

# Encrypt data
vault write transit/encrypt/my-key plaintext=$(base64 <<< "data")

# Decrypt data
vault write transit/decrypt/my-key ciphertext=vault:v1:abc...

# Create policy
vault policy write my-policy policy.hcl

# Enable secrets engine
vault secrets enable -path=database database

# Enable auth method
vault auth enable kubernetes
```

---

## Resources for Deep Dive

- **Vault Documentation:** vault.io/docs
- **Vault Tutorials:** learn.hashicorp.com/vault
- **Vault Associate Certification:** Study guide if she wants to go deeper
- **Architecture Guides:** vault.io/docs/internals/architecture

