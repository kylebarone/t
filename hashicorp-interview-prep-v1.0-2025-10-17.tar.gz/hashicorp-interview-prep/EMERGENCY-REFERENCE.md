# EMERGENCY REFERENCE - Keep This Open During Interview

## 30-Second Pitches

**Terraform:** "Terraform is infrastructure as code - define cloud resources in config files, deploy consistently across environments. Companies go from weeks to minutes for provisioning. Complete audit trail, no configuration drift."

**Vault:** "Vault manages secrets securely. Dynamic credentials expire automatically, reducing breach risk. Every access is audited. Pass compliance automatically."

**Together:** "Terraform provisions infrastructure, Vault secures it. No credentials in code. Enterprise-grade automation with built-in security."

---

## Discovery Questions (SPIN)

**Situation:** "How do you provision infrastructure today?"
**Problem:** "What's your biggest challenge?"
**Implication:** "How does that affect time to market?"
**Need-Payoff:** "What if you could provision in minutes?"

---

## Key Technical Answers

**TCP vs UDP:**
TCP = Reliable, ordered, slower (web, email, databases)
UDP = Fast, no guarantees (video, gaming, DNS)

**Why Terraform:**
• Multi-cloud (not locked to one provider)
• Declarative (describe what you want)
• State management (tracks reality)
• Huge ecosystem (3,000+ providers)

**Why Vault:**
• Dynamic secrets (temporary, auto-expire)
• Centralized (single source of truth)
• Audit trail (compliance ready)
• Encryption service (PCI, HIPAA, GDPR)

---

## Common Objections

**"Too expensive"**
→ "ROI in 6-9 months. What did last outage cost?"

**"Too complex"**
→ "Complexity exists either way. Code is reviewable and documentable."

**"CloudFormation works"**
→ "Great for AWS-only. Multi-cloud needs one tool."

**"Vendor lock-in"**
→ "Open source. Actually reduces cloud lock-in."

---

## Value Props Quick Hits

**Multi-Cloud:** One tool, all clouds
**Security:** Pass audits automatically
**Speed:** 10x faster provisioning
**Cost:** 20-40% reduction possible
**Compliance:** Policy as code (Sentinel)

---

## Enterprise Features

**Terraform Enterprise:**
• Sentinel (policy as code)
• Cost estimation
• Private modules
• RBAC & SSO
• Audit logs

**Vault Enterprise:**
• Namespaces (multi-tenancy)
• DR replication
• HSM support
• Performance replicas

---

## Your Examples

**Weekend Project:** "I built a 3-tier app with Terraform + Vault. Auto-scaling web tier, RDS database, dynamic credentials from Vault. Multi-AZ for HA."

**Architecture Decision:** "Used ALB for Layer 7 routing, separate subnets per tier, NAT gateways for private subnet internet access."

---

## Client Personas

**CISO:** Audit failures → Vault audit logs
**VP Eng:** Slow provisioning → Terraform Cloud
**Platform Team:** Manual toil → IaC automation
**CFO:** Cost overruns → Cost estimation

---

## Red Flags to Avoid

❌ Feature dumping without business value
❌ Not listening to their actual problem
❌ Faking knowledge you don't have
❌ Only technical, no business translation

✓ Lead with business outcomes
✓ Ask clarifying questions
✓ "I don't know but here's how I'd find out"
✓ Show enthusiasm

---

## Your Questions to Ask

1. "What does success look like in first 90 days?"
2. "How does SE collaborate with sales?"
3. "What are customers' biggest challenges?"
4. "How does HashiCorp support SE growth?"

---

## Confidence Reminders

✓ You've prepared thoroughly
✓ You have hands-on project to reference
✓ You understand the business value
✓ Your enthusiasm is genuine
✓ It's okay to say "I don't know"
✓ Problem-solving > memorization

**Breathe. Smile. You've got this. 🚀**

