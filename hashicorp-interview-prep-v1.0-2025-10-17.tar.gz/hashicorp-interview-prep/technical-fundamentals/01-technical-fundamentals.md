# Technical Fundamentals for Solutions Engineering

## Networking & Protocols

### TCP vs UDP

**TCP (Transmission Control Protocol)**
- **Connection-oriented:** Establishes connection before data transfer (3-way handshake)
- **Reliable:** Guarantees delivery, retransmits lost packets
- **Ordered:** Data arrives in the order sent
- **Error-checking:** Built-in error detection and correction
- **Slower:** Due to overhead of reliability mechanisms
- **Flow control:** Manages data transmission rate

**Use Cases:**
- Web browsing (HTTP/HTTPS)
- Email (SMTP, IMAP)
- File transfers (FTP, SFTP)
- SSH connections
- Database connections
- **Anywhere reliability > speed**

**UDP (User Datagram Protocol)**
- **Connectionless:** No connection establishment, just send data
- **Unreliable:** No guarantee of delivery, no retransmission
- **Unordered:** Packets may arrive out of order
- **Minimal error-checking:** Basic checksum only
- **Faster:** Less overhead = lower latency
- **No flow control:** Sender determines transmission rate

**Use Cases:**
- Video/audio streaming (Netflix, Zoom)
- Online gaming (low latency critical)
- DNS queries (quick lookups)
- VoIP (Voice over IP)
- IoT sensor data
- **Anywhere speed/latency > reliability**

**Interview Answer Template:**
"TCP is like certified mail - you get confirmation of delivery but it takes longer. UDP is like shouting across a room - faster but you're not sure they heard you. For streaming video, occasional dropped frames are okay, so UDP's speed wins. For financial transactions, you need TCP's reliability."

---

### OSI Model (7 Layers)

**Why This Matters:** Troubleshooting network issues, understanding where security/monitoring fits

| Layer | Name | What It Does | Examples | Troubleshooting |
|-------|------|--------------|----------|-----------------|
| 7 | Application | User-facing protocols | HTTP, FTP, SMTP, DNS | Application errors, API issues |
| 6 | Presentation | Data formatting, encryption | SSL/TLS, JPEG, ASCII | Encryption issues, data format errors |
| 5 | Session | Manages connections | NetBIOS, RPC | Session timeouts, authentication issues |
| 4 | Transport | End-to-end delivery | **TCP, UDP** | Port issues, connection problems |
| 3 | Network | Routing between networks | **IP, ICMP** | Routing issues, can't reach host |
| 2 | Data Link | Node-to-node transfer | Ethernet, MAC addresses | Switch issues, local network problems |
| 1 | Physical | Physical connection | Cables, WiFi, fiber | Cable unplugged, hardware failure |

**Practical Example:**
"If a user can't access a website, I'd troubleshoot from Layer 7 down: Is DNS resolving? (Layer 7) Is the SSL certificate valid? (Layer 6) Is the TCP connection established? (Layer 4) Can we ping the server? (Layer 3) Is the network cable connected? (Layer 1)"

---

### IP Addressing & Subnetting

**IPv4 Address:** 192.168.1.10
- 32 bits (4 octets)
- Each octet: 0-255
- ~4.3 billion addresses (running out!)

**IPv6 Address:** 2001:0db8:85a3:0000:0000:8a2e:0370:7334
- 128 bits
- Virtually unlimited addresses
- Still being adopted

**CIDR Notation:** 192.168.1.0/24
- /24 = subnet mask (how many bits for network vs host)
- /24 = 255.255.255.0 = 256 addresses (254 usable)
- /16 = 255.255.0.0 = 65,536 addresses
- /8 = 255.0.0.0 = 16,777,216 addresses

**Private IP Ranges (RFC 1918):**
- 10.0.0.0/8 (10.0.0.0 - 10.255.255.255)
- 172.16.0.0/12 (172.16.0.0 - 172.31.255.255)
- 192.168.0.0/16 (192.168.0.0 - 192.168.255.255)

**Why This Matters for Solutions:**
"When designing a VPC, we need to choose a CIDR block that's large enough for growth but doesn't waste IPs. For example, a /16 gives you 65k addresses - enough for multiple subnets across availability zones."

---

### DNS (Domain Name System)

**What it does:** Translates domain names to IP addresses

**DNS Record Types:**
- **A Record:** Domain → IPv4 address (example.com → 192.168.1.1)
- **AAAA Record:** Domain → IPv6 address
- **CNAME:** Alias (www.example.com → example.com)
- **MX:** Mail server records
- **TXT:** Text records (SPF, DKIM, verification)
- **NS:** Nameserver records

**DNS Resolution Flow:**
1. Browser checks cache
2. Queries local DNS resolver
3. Resolver queries root nameserver
4. Root points to TLD nameserver (.com)
5. TLD points to authoritative nameserver
6. Authoritative returns IP address
7. Browser connects to IP

**Why This Matters:**
"When deploying infrastructure, DNS propagation can take time. We need to plan for TTL (Time To Live) settings - lower TTL for faster updates but more DNS queries."

---

### Load Balancing

**Types:**

**Layer 4 (Transport Layer):**
- Routes based on IP address and TCP/UDP port
- Faster (less inspection)
- No visibility into application data
- Example: NLB (Network Load Balancer)

**Layer 7 (Application Layer):**
- Routes based on HTTP headers, URLs, cookies
- Content-based routing (example.com/api → backend1, example.com/web → backend2)
- SSL termination
- Example: ALB (Application Load Balancer)

**Algorithms:**
- **Round Robin:** Distribute requests evenly
- **Least Connections:** Send to server with fewest connections
- **IP Hash:** Same client always goes to same server (session affinity)
- **Weighted:** Distribute based on server capacity

**Health Checks:**
- Ping health endpoint every X seconds
- Mark unhealthy after Y failed checks
- Stop sending traffic to unhealthy instances
- Automatic failover

**Why This Matters:**
"For a stateless API, round-robin works great. But if users have shopping carts (session state), we need session affinity or a shared session store like Redis."

---

## Security Concepts

### Encryption

**Encryption at Rest:**
- Data stored on disk is encrypted
- Protection if disk is stolen
- Examples: EBS encryption, S3 encryption, database encryption

**Encryption in Transit:**
- Data encrypted during transmission
- Protection against man-in-the-middle attacks
- Examples: HTTPS (TLS/SSL), SSH, VPN

**Symmetric Encryption:**
- Same key for encryption and decryption
- Fast
- Key distribution is challenging
- Example: AES-256

**Asymmetric Encryption:**
- Public key (encrypt) + Private key (decrypt)
- Slower but solves key distribution
- Example: RSA

**Why This Matters:**
"For compliance (PCI, HIPAA, GDPR), we need encryption at rest AND in transit. Terraform makes this easy with default encryption options for most resources."

---

### Authentication vs Authorization

**Authentication:** WHO are you?
- Verifying identity
- Username/password, MFA, certificates, biometrics
- "Prove you are who you say you are"

**Authorization:** WHAT can you do?
- Verifying permissions
- Role-based access control (RBAC)
- "You're authenticated as Alice, but can you access this resource?"

**Example:**
"You log into AWS (authentication), but you can only create EC2 instances in us-east-1 (authorization based on IAM policy)."

---

### Zero Trust Security

**Traditional:** "Trust but verify" - trusted network perimeter
**Zero Trust:** "Never trust, always verify" - no implicit trust

**Principles:**
1. Verify explicitly (always authenticate/authorize)
2. Use least privilege access
3. Assume breach (segment network, monitor everything)

**Implementation:**
- Multi-factor authentication everywhere
- Micro-segmentation (network security groups)
- Continuous monitoring and validation
- Dynamic access based on context

**HashiCorp Alignment:**
- **Vault:** Identity-based secrets access
- **Consul:** Service mesh with mTLS
- **Boundary:** Identity-based infrastructure access

---

## Cloud Concepts

### Regions & Availability Zones

**Region:** Geographic area (us-east-1, eu-west-1)
- Independent infrastructure
- Latency to users
- Data residency requirements

**Availability Zone:** Isolated data centers within a region
- Separate power, cooling, networking
- Connected via low-latency links
- Typically 3-6 AZs per region

**High Availability Design:**
- Deploy across multiple AZs
- Each AZ is an independent failure domain
- If one AZ fails, others continue

**Example:**
"We deploy the web tier in 3 AZs. If AZ-a has an outage, AZ-b and AZ-c handle the traffic. The load balancer automatically routes around the failed AZ."

---

### Compute Models

**Virtual Machines (IaaS):**
- EC2, Azure VMs, Compute Engine
- Full control over OS
- Lift-and-shift friendly
- You manage: OS, patches, scaling

**Containers (CaaS):**
- ECS, AKS, GKE
- Lighter than VMs
- Portable across environments
- You manage: Container orchestration, scaling

**Serverless (FaaS):**
- Lambda, Azure Functions, Cloud Functions
- No servers to manage
- Pay per invocation
- Auto-scales
- You manage: Just code

**When to Use What:**
- **VMs:** Legacy apps, need full OS control, persistent workloads
- **Containers:** Microservices, cloud-native apps, portability
- **Serverless:** Event-driven, variable traffic, reduce ops overhead

---

### Storage Types

**Object Storage:**
- S3, Azure Blob, Cloud Storage
- Flat namespace (no hierarchy, but simulated with prefixes)
- Unlimited scale
- HTTP API access
- Use: Static websites, backups, data lakes, media files

**Block Storage:**
- EBS, Azure Disk, Persistent Disks
- Attached to compute instances
- Low-latency, high-performance
- Use: Database storage, boot volumes

**File Storage:**
- EFS, Azure Files, Filestore
- Shared file system (NFS/SMB)
- Multiple instances can mount
- Use: Shared application data, content management

**Why This Matters:**
"For a web application's static assets (images, CSS, JS), object storage is perfect - it's cheap and scales infinitely. But for the database, we need block storage for low-latency random access."

---

### Database Types

**Relational (SQL):**
- MySQL, PostgreSQL, SQL Server
- Structured data, tables with relationships
- ACID transactions
- Strong consistency
- Use: Financial systems, inventory, CRM

**NoSQL:**

**Document:** MongoDB, DynamoDB, CosmosDB
- Flexible schema (JSON documents)
- Fast reads/writes
- Use: User profiles, catalogs, content management

**Key-Value:** Redis, DynamoDB
- Simplest model
- Extremely fast
- Use: Session storage, caching, real-time data

**Column-Family:** Cassandra, HBase
- Optimized for large-scale writes
- Distributed
- Use: Time-series data, IoT, analytics

**Graph:** Neo4j, Neptune
- Relationships are first-class citizens
- Use: Social networks, recommendation engines, fraud detection

**When to Use What:**
"For an e-commerce site, I'd use PostgreSQL for orders/inventory (need transactions), Redis for session data (need speed), and Elasticsearch for product search (need full-text search)."

---

## API Concepts

### REST vs GraphQL

**REST (Representational State Transfer):**
- Resource-based URLs (/users, /users/123)
- HTTP verbs (GET, POST, PUT, DELETE)
- Multiple endpoints
- Can over-fetch or under-fetch data
- Widely adopted, simple

**GraphQL:**
- Single endpoint
- Client specifies exactly what data needed
- Solves over-fetching/under-fetching
- Strongly typed schema
- More complex to implement

**Example:**
REST: 3 requests for user, posts, comments
GraphQL: 1 request with nested query

---

### Rate Limiting

**Why:** Prevent abuse, ensure fair usage, protect backend

**Strategies:**
- **Fixed Window:** 100 requests per hour (resets at :00)
- **Sliding Window:** 100 requests per rolling hour
- **Token Bucket:** Refill tokens at steady rate, consume per request
- **Leaky Bucket:** Queue requests, process at steady rate

**HTTP Status Codes:**
- 429 Too Many Requests
- Headers: X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset

---

## Container Concepts

### Docker Basics

**Container:** Lightweight, standalone executable package
- Includes code, runtime, libraries, dependencies
- Isolated from host and other containers
- Shares host OS kernel (unlike VMs)

**Image:** Blueprint for containers
- Built from Dockerfile
- Layered file system
- Versioned and tagged
- Stored in registries (Docker Hub, ECR, ACR)

**Dockerfile Example:**
```dockerfile
FROM node:18
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

**Why Containers Matter:**
"Containers solve 'works on my machine' - consistent environment from dev to prod. Makes scaling easy - just run more containers. Perfect for microservices architecture."

---

### Kubernetes (K8s) Basics

**What it is:** Container orchestration platform
- Automated deployment, scaling, management
- Self-healing
- Load balancing
- Service discovery

**Key Concepts:**
- **Pod:** Smallest unit, one or more containers
- **Deployment:** Manages replica sets and rolling updates
- **Service:** Stable endpoint for pods (load balancing)
- **Namespace:** Virtual clusters within K8s
- **ConfigMap/Secret:** Configuration and sensitive data
- **Ingress:** HTTP/HTTPS routing

**Why This Matters:**
"Kubernetes abstracts away the infrastructure. Developers declare desired state (run 10 replicas), K8s makes it happen. Terraform provisions the K8s cluster, then apps are deployed via K8s manifests."

---

## Monitoring & Observability

### The Three Pillars

**1. Logs:**
- Discrete events (user logged in, error occurred)
- Searchable, filterable
- Tools: CloudWatch Logs, Splunk, ELK stack

**2. Metrics:**
- Numerical measurements over time
- CPU usage, request rate, error rate
- Tools: CloudWatch Metrics, Prometheus, Datadog

**3. Traces:**
- Request journey through distributed system
- Identify bottlenecks
- Tools: X-Ray, Jaeger, Zipkin

**Why All Three:**
"Metrics tell you something is wrong. Logs tell you what went wrong. Traces tell you where it went wrong."

---

### SLIs, SLOs, SLAs

**SLI (Service Level Indicator):**
- Quantitative measure of service
- Examples: API latency, error rate, availability

**SLO (Service Level Objective):**
- Target value for SLI
- Example: 99.9% uptime, p99 latency < 200ms

**SLA (Service Level Agreement):**
- Contract with consequences
- Example: "99.95% uptime or customer gets credit"

**Relationship:** SLA ≥ SLO based on SLIs

**Why This Matters:**
"When designing infrastructure, we work backward from SLAs. If we promise 99.9% uptime, we need redundancy, monitoring, and automated failover."

---

## DevOps & CI/CD

### CI/CD Pipeline

**Continuous Integration (CI):**
- Automatically build and test code on commit
- Catch bugs early
- Tools: GitHub Actions, GitLab CI, Jenkins

**Continuous Delivery (CD):**
- Automatically deploy to staging/production
- One-click production deployment
- Tools: ArgoCD, Spinnaker, Terraform Cloud

**Continuous Deployment:**
- Fully automated to production
- No manual gate

**Terraform in CI/CD:**
```
Code Commit → CI runs terraform plan
           → Manual approval
           → CD runs terraform apply
           → Infrastructure updated
```

---

### Infrastructure as Code (IaC)

**Benefits:**
1. **Version Control:** Infrastructure changes tracked in Git
2. **Reproducibility:** Same code = same infrastructure
3. **Documentation:** Code documents architecture
4. **Collaboration:** Team can review infrastructure changes
5. **Testing:** Can test infrastructure in staging
6. **Disaster Recovery:** Rebuild from code

**Terraform vs Alternatives:**
- **CloudFormation:** AWS-only
- **ARM Templates:** Azure-only
- **Terraform:** Multi-cloud, larger ecosystem, better state management

---

## Interview Preparation Tips

### Technical Questions Pattern

**Question:** "What's the difference between X and Y?"

**Good Answer Structure:**
1. Define X briefly
2. Define Y briefly
3. Key difference
4. When to use X
5. When to use Y
6. Real-world example

**Example:**
Q: "TCP vs UDP?"
A: "TCP is connection-oriented and reliable, UDP is connectionless and faster. TCP guarantees delivery through acknowledgments and retransmission, while UDP has no such overhead. Use TCP when reliability is critical - like database connections or file transfers. Use UDP when speed matters more - like video streaming where dropped frames are acceptable. For example, Zoom uses UDP because a few dropped packets won't ruin the call, but delay would."

---

### Relating to HashiCorp Products

**Always Circle Back:**
- "This is why Vault's dynamic secrets are powerful - short-lived credentials reduce the blast radius."
- "Terraform handles this networking complexity - we can define VPC, subnets, routing tables declaratively."
- "Consul provides service discovery here, so containers can find each other without hardcoded IPs."

---

### Handling "I Don't Know"

**Better than guessing:**
"That's not an area I've worked with recently, but based on my understanding of [related concept], I would approach it by [logical reasoning]. I'd want to research [specific resource] to give you a complete answer."

**Shows:**
- Honesty
- Problem-solving ability
- Willingness to learn
- How you'd handle client questions you don't know

---

## Quick Reference Cheat Sheet

### Ports to Know
- 22: SSH
- 80: HTTP
- 443: HTTPS
- 3306: MySQL
- 5432: PostgreSQL
- 6379: Redis
- 8200: Vault
- 8500: Consul

### HTTP Status Codes
- 200: OK
- 201: Created
- 400: Bad Request (client error)
- 401: Unauthorized (not authenticated)
- 403: Forbidden (authenticated but no permission)
- 404: Not Found
- 500: Internal Server Error (server problem)
- 503: Service Unavailable (overloaded/down)

### Common Architecture Patterns
- **Monolith:** Single application, simple but hard to scale
- **Microservices:** Small, independent services, complex but scalable
- **Serverless:** Event-driven functions, no servers to manage
- **3-Tier:** Web, app, data layers separated
- **Event-Driven:** Services communicate via events/messages

---

## Practice Scenarios

### Scenario 1: Client Can't Access Application
**Troubleshooting Steps:**
1. Can you ping the server? (Layer 3)
2. Is the port open? (Layer 4)
3. Is the application running? (Layer 7)
4. Check security groups/firewall
5. Check load balancer health checks
6. Check DNS resolution

### Scenario 2: Application is Slow
**Investigation:**
1. Check metrics (CPU, memory, disk, network)
2. Review logs for errors
3. Check database query performance
4. Look for increased traffic (DDoS?)
5. Review recent changes (deployments?)

### Scenario 3: Design HA Web Application
**Solution:**
1. Multi-AZ deployment
2. Auto-scaling groups
3. Load balancer
4. Read replicas for database
5. CloudFront for static content
6. S3 for backups
7. Route 53 for DNS with health checks

---

**Remember:** In a solutions engineering interview, it's not just about knowing the answer - it's about showing how you think, how you'd work with clients, and how HashiCorp products solve real problems.

