# Weekend Project Guide: Hands-On HashiCorp Practice

## Project Overview

**Goal:** Build a production-like, secure 3-tier web application with Terraform and Vault
**Time:** 6-8 hours over a weekend
**Cloud:** AWS (free tier eligible) or use LocalStack for local development
**Skills Gained:** Terraform modules, Vault integration, security best practices, architecture design

---

## Project Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     AWS Cloud                            │
│                                                           │
│  ┌──────────────────────────────────────────────────┐  │
│  │               VPC (10.0.0.0/16)                   │  │
│  │                                                    │  │
│  │  Public Subnets (Multi-AZ)                        │  │
│  │  ┌──────────┐        ┌──────────┐               │  │
│  │  │   ALB    │        │  Bastion │               │  │
│  │  └────┬─────┘        └──────────┘               │  │
│  │       │                                           │  │
│  │  Private Subnets (Multi-AZ)                       │  │
│  │  ┌────▼─────────────────────┐                    │  │
│  │  │  Auto Scaling Group       │                    │  │
│  │  │  (Web/App Instances)      │                    │  │
│  │  │  - Retrieve DB creds      │                    │  │
│  │  │    from Vault             │                    │  │
│  │  └────┬──────────────────────┘                   │  │
│  │       │                                           │  │
│  │  Database Subnets (Multi-AZ)                      │  │
│  │  ┌────▼─────┐                                     │  │
│  │  │   RDS    │                                     │  │
│  │  │ PostgreSQL                                     │  │
│  │  └──────────┘                                     │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘

External:
┌──────────────┐
│   Vault      │ (Running locally or in separate instance)
│   Server     │
└──────────────┘
```

---

## Prerequisites

### Setup (30 minutes)

1. **AWS Account**
   ```bash
   # Install AWS CLI
   brew install awscli  # or apt-get/choco
   
   # Configure credentials
   aws configure
   # Enter: Access Key, Secret Key, Region (us-east-1), Output (json)
   ```

2. **Terraform**
   ```bash
   # Install Terraform
   brew install terraform  # or download from terraform.io
   
   # Verify
   terraform version
   ```

3. **Vault**
   ```bash
   # Install Vault
   brew install vault  # or download from vaultproject.io
   
   # Verify
   vault version
   ```

4. **Project Structure**
   ```bash
   mkdir weekend-hashicorp-project
   cd weekend-hashicorp-project
   
   # Create directory structure
   mkdir -p {modules/{networking,compute,database,security},environments/{dev,prod}}
   ```

---

## Phase 1: Networking Module (60 minutes)

### Goal: Create reusable VPC module with public/private subnets

**File: `modules/networking/main.tf`**
```hcl
# VPC
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "${var.environment}-vpc"
    Environment = var.environment
    ManagedBy   = "Terraform"
  }
}

# Internet Gateway
resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id

  tags = {
    Name        = "${var.environment}-igw"
    Environment = var.environment
  }
}

# Public Subnets (for ALB)
resource "aws_subnet" "public" {
  count             = length(var.availability_zones)
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, count.index)
  availability_zone = var.availability_zones[count.index]
  
  map_public_ip_on_launch = true

  tags = {
    Name        = "${var.environment}-public-${var.availability_zones[count.index]}"
    Environment = var.environment
    Tier        = "Public"
  }
}

# Private Subnets (for App tier)
resource "aws_subnet" "private" {
  count             = length(var.availability_zones)
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, count.index + 10)
  availability_zone = var.availability_zones[count.index]

  tags = {
    Name        = "${var.environment}-private-${var.availability_zones[count.index]}"
    Environment = var.environment
    Tier        = "Private"
  }
}

# Database Subnets
resource "aws_subnet" "database" {
  count             = length(var.availability_zones)
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, count.index + 20)
  availability_zone = var.availability_zones[count.index]

  tags = {
    Name        = "${var.environment}-database-${var.availability_zones[count.index]}"
    Environment = var.environment
    Tier        = "Database"
  }
}

# NAT Gateway (for private subnet internet access)
resource "aws_eip" "nat" {
  count  = length(var.availability_zones)
  domain = "vpc"

  tags = {
    Name        = "${var.environment}-nat-eip-${count.index + 1}"
    Environment = var.environment
  }
}

resource "aws_nat_gateway" "main" {
  count         = length(var.availability_zones)
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id

  tags = {
    Name        = "${var.environment}-nat-${count.index + 1}"
    Environment = var.environment
  }
}

# Route Tables
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.main.id
  }

  tags = {
    Name        = "${var.environment}-public-rt"
    Environment = var.environment
  }
}

resource "aws_route_table" "private" {
  count  = length(var.availability_zones)
  vpc_id = aws_vpc.main.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.main[count.index].id
  }

  tags = {
    Name        = "${var.environment}-private-rt-${count.index + 1}"
    Environment = var.environment
  }
}

# Route Table Associations
resource "aws_route_table_association" "public" {
  count          = length(var.availability_zones)
  subnet_id      = aws_subnet.public[count.index].id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table_association" "private" {
  count          = length(var.availability_zones)
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private[count.index].id
}
```

**File: `modules/networking/variables.tf`**
```hcl
variable "environment" {
  description = "Environment name"
  type        = string
}

variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  description = "List of availability zones"
  type        = list(string)
  default     = ["us-east-1a", "us-east-1b"]
}
```

**File: `modules/networking/outputs.tf`**
```hcl
output "vpc_id" {
  value = aws_vpc.main.id
}

output "public_subnet_ids" {
  value = aws_subnet.public[*].id
}

output "private_subnet_ids" {
  value = aws_subnet.private[*].id
}

output "database_subnet_ids" {
  value = aws_subnet.database[*].id
}
```

---

## Phase 2: Database Module (45 minutes)

### Goal: Create RDS instance with Vault integration

**File: `modules/database/main.tf`**
```hcl
# DB Subnet Group
resource "aws_db_subnet_group" "main" {
  name       = "${var.environment}-db-subnet-group"
  subnet_ids = var.database_subnet_ids

  tags = {
    Name        = "${var.environment}-db-subnet-group"
    Environment = var.environment
  }
}

# Security Group for RDS
resource "aws_security_group" "rds" {
  name        = "${var.environment}-rds-sg"
  description = "Security group for RDS instance"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [var.app_security_group_id]
    description     = "PostgreSQL from app tier"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "${var.environment}-rds-sg"
    Environment = var.environment
  }
}

# RDS Instance
resource "aws_db_instance" "main" {
  identifier     = "${var.environment}-postgres"
  engine         = "postgres"
  engine_version = "15.3"
  
  instance_class    = var.instance_class
  allocated_storage = var.allocated_storage
  storage_encrypted = true
  
  db_name  = var.database_name
  username = var.master_username
  password = var.master_password
  
  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.rds.id]
  
  multi_az               = var.multi_az
  backup_retention_period = 7
  backup_window          = "03:00-04:00"
  maintenance_window     = "mon:04:00-mon:05:00"
  
  skip_final_snapshot = var.environment == "dev" ? true : false
  final_snapshot_identifier = var.environment == "dev" ? null : "${var.environment}-final-snapshot"
  
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]

  tags = {
    Name        = "${var.environment}-postgres"
    Environment = var.environment
    ManagedBy   = "Terraform"
  }
}
```

**File: `modules/database/variables.tf`**
```hcl
variable "environment" {
  description = "Environment name"
  type        = string
}

variable "vpc_id" {
  description = "VPC ID"
  type        = string
}

variable "database_subnet_ids" {
  description = "List of database subnet IDs"
  type        = list(string)
}

variable "app_security_group_id" {
  description = "Security group ID for app tier"
  type        = string
}

variable "instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "allocated_storage" {
  description = "Allocated storage in GB"
  type        = number
  default     = 20
}

variable "database_name" {
  description = "Database name"
  type        = string
  default     = "appdb"
}

variable "master_username" {
  description = "Master username"
  type        = string
  sensitive   = true
}

variable "master_password" {
  description = "Master password"
  type        = string
  sensitive   = true
}

variable "multi_az" {
  description = "Enable Multi-AZ"
  type        = bool
  default     = false
}
```

**File: `modules/database/outputs.tf`**
```hcl
output "endpoint" {
  value = aws_db_instance.main.endpoint
}

output "address" {
  value = aws_db_instance.main.address
}

output "port" {
  value = aws_db_instance.main.port
}
```

---

## Phase 3: Vault Setup (60 minutes)

### Goal: Set up Vault with database secrets engine

**Step 1: Start Vault in Dev Mode (for learning)**
```bash
# Terminal 1 - Start Vault server
vault server -dev

# Note the Root Token and Unseal Key shown in output
# Export the Vault address
export VAULT_ADDR='http://127.0.0.1:8200'
export VAULT_TOKEN='<root-token-from-output>'
```

**Step 2: Configure Database Secrets Engine**
```bash
# Enable database secrets engine
vault secrets enable database

# Configure PostgreSQL connection
# (Replace with your RDS endpoint after Terraform creates it)
vault write database/config/mydb \
    plugin_name=postgresql-database-plugin \
    allowed_roles="readonly,readwrite" \
    connection_url="postgresql://{{username}}:{{password}}@<RDS_ENDPOINT>:5432/appdb" \
    username="admin" \
    password="<your-master-password>"

# Create readonly role
vault write database/roles/readonly \
    db_name=mydb \
    creation_statements="CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}'; \
        GRANT SELECT ON ALL TABLES IN SCHEMA public TO \"{{name}}\";" \
    default_ttl="1h" \
    max_ttl="24h"

# Create readwrite role
vault write database/roles/readwrite \
    db_name=mydb \
    creation_statements="CREATE ROLE \"{{name}}\" WITH LOGIN PASSWORD '{{password}}' VALID UNTIL '{{expiration}}'; \
        GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO \"{{name}}\";" \
    default_ttl="2h" \
    max_ttl="24h"
```

**Step 3: Test Vault**
```bash
# Request credentials
vault read database/creds/readonly

# Output will show:
# Key                Value
# ---                -----
# lease_id           database/creds/readonly/abc123
# lease_duration     1h
# lease_renewable    true
# password           A1a-xyz...
# username           v-root-readonly-abc123
```

**Step 4: Create Vault Policy for App**
```bash
# Create policy file
cat > app-policy.hcl <<EOF
path "database/creds/readwrite" {
  capabilities = ["read"]
}

path "secret/data/app/*" {
  capabilities = ["read", "list"]
}
EOF

# Write policy to Vault
vault policy write app-policy app-policy.hcl

# Create token for app
vault token create -policy=app-policy
# Note the token for use in app
```

---

## Phase 4: Compute Module with Vault Integration (90 minutes)

### Goal: Create auto-scaling app tier that retrieves DB credentials from Vault

**File: `modules/compute/main.tf`**
```hcl
# Security Group for App Instances
resource "aws_security_group" "app" {
  name        = "${var.environment}-app-sg"
  description = "Security group for application instances"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 80
    to_port         = 80
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
    description     = "HTTP from ALB"
  }

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/16"]  # From within VPC only
    description = "SSH from within VPC"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "${var.environment}-app-sg"
    Environment = var.environment
  }
}

# IAM Role for EC2 instances
resource "aws_iam_role" "app" {
  name = "${var.environment}-app-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "app_ssm" {
  role       = aws_iam_role.app.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_instance_profile" "app" {
  name = "${var.environment}-app-profile"
  role = aws_iam_role.app.name
}

# User Data Script (installs app + Vault agent)
locals {
  user_data = <<-EOF
    #!/bin/bash
    set -e
    
    # Update system
    yum update -y
    
    # Install Vault
    yum install -y yum-utils
    yum-config-manager --add-repo https://rpm.releases.hashicorp.com/AmazonLinux/hashicorp.repo
    yum -y install vault
    
    # Install Docker
    yum install -y docker
    systemctl start docker
    systemctl enable docker
    
    # Create Vault config for agent
    mkdir -p /etc/vault-agent
    cat > /etc/vault-agent/config.hcl <<CONFIG
    vault {
      address = "${var.vault_address}"
    }
    
    auto_auth {
      method {
        type = "token"
        config = {
          token = "${var.vault_token}"
        }
      }
      
      sink {
        type = "file"
        config = {
          path = "/tmp/vault-token"
        }
      }
    }
    
    template {
      source      = "/etc/vault-agent/db-creds.tpl"
      destination = "/tmp/db-creds.json"
      command     = "systemctl restart myapp"
    }
    CONFIG
    
    # Create template for DB credentials
    cat > /etc/vault-agent/db-creds.tpl <<TEMPLATE
    {
      "username": "{{ with secret "database/creds/readwrite" }}{{ .Data.username }}{{ end }}",
      "password": "{{ with secret "database/creds/readwrite" }}{{ .Data.password }}{{ end }}"
    }
    TEMPLATE
    
    # Start simple web app
    cat > /tmp/app.py <<PYAPP
    from flask import Flask, jsonify
    import json
    import psycopg2
    
    app = Flask(__name__)
    
    @app.route('/')
    def hello():
        return jsonify({"message": "Hello from Terraform + Vault!", "environment": "${var.environment}"})
    
    @app.route('/health')
    def health():
        return jsonify({"status": "healthy"})
    
    @app.route('/db-test')
    def db_test():
        # Read Vault credentials
        with open('/tmp/db-creds.json') as f:
            creds = json.load(f)
        
        try:
            conn = psycopg2.connect(
                host="${var.db_host}",
                database="${var.db_name}",
                user=creds['username'],
                password=creds['password']
            )
            cur = conn.cursor()
            cur.execute('SELECT version();')
            version = cur.fetchone()
            cur.close()
            conn.close()
            return jsonify({"database": "connected", "version": version[0]})
        except Exception as e:
            return jsonify({"database": "error", "message": str(e)}), 500
    
    if __name__ == '__main__':
        app.run(host='0.0.0.0', port=80)
    PYAPP
    
    # Install Python dependencies
    yum install -y python3 python3-pip
    pip3 install flask psycopg2-binary
    
    # Create systemd service
    cat > /etc/systemd/system/myapp.service <<SERVICE
    [Unit]
    Description=My App
    After=network.target
    
    [Service]
    Type=simple
    User=root
    WorkingDirectory=/tmp
    ExecStart=/usr/bin/python3 /tmp/app.py
    Restart=always
    
    [Install]
    WantedBy=multi-user.target
    SERVICE
    
    # Start app
    systemctl daemon-reload
    systemctl enable myapp
    systemctl start myapp
    
    # Start Vault agent
    vault agent -config=/etc/vault-agent/config.hcl &
  EOF
}

# Launch Template
resource "aws_launch_template" "app" {
  name_prefix   = "${var.environment}-app-"
  image_id      = var.ami_id
  instance_type = var.instance_type
  
  iam_instance_profile {
    name = aws_iam_instance_profile.app.name
  }
  
  vpc_security_group_ids = [aws_security_group.app.id]
  
  user_data = base64encode(local.user_data)
  
  tag_specifications {
    resource_type = "instance"
    tags = {
      Name        = "${var.environment}-app"
      Environment = var.environment
    }
  }
}

# Auto Scaling Group
resource "aws_autoscaling_group" "app" {
  name                = "${var.environment}-app-asg"
  vpc_zone_identifier = var.private_subnet_ids
  target_group_arns   = [aws_lb_target_group.app.arn]
  health_check_type   = "ELB"
  
  min_size         = var.min_size
  max_size         = var.max_size
  desired_capacity = var.desired_capacity
  
  launch_template {
    id      = aws_launch_template.app.id
    version = "$Latest"
  }
  
  tag {
    key                 = "Name"
    value               = "${var.environment}-app"
    propagate_at_launch = true
  }
  
  tag {
    key                 = "Environment"
    value               = var.environment
    propagate_at_launch = true
  }
}

# Application Load Balancer
resource "aws_security_group" "alb" {
  name        = "${var.environment}-alb-sg"
  description = "Security group for ALB"
  vpc_id      = var.vpc_id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTP from internet"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "${var.environment}-alb-sg"
    Environment = var.environment
  }
}

resource "aws_lb" "app" {
  name               = "${var.environment}-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = var.public_subnet_ids

  tags = {
    Name        = "${var.environment}-alb"
    Environment = var.environment
  }
}

resource "aws_lb_target_group" "app" {
  name     = "${var.environment}-tg"
  port     = 80
  protocol = "HTTP"
  vpc_id   = var.vpc_id
  
  health_check {
    path                = "/health"
    healthy_threshold   = 2
    unhealthy_threshold = 10
    timeout             = 5
    interval            = 30
  }

  tags = {
    Name        = "${var.environment}-tg"
    Environment = var.environment
  }
}

resource "aws_lb_listener" "app" {
  load_balancer_arn = aws_lb.app.arn
  port              = "80"
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.app.arn
  }
}
```

---

## Phase 5: Environment Configuration (30 minutes)

**File: `environments/dev/main.tf`**
```hcl
terraform {
  required_version = ">= 1.0"
  
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
  
  # For production, use remote backend
  # backend "s3" {
  #   bucket = "my-terraform-state"
  #   key    = "dev/terraform.tfstate"
  #   region = "us-east-1"
  # }
}

provider "aws" {
  region = var.aws_region
}

# Networking
module "networking" {
  source = "../../modules/networking"
  
  environment        = var.environment
  vpc_cidr           = "10.0.0.0/16"
  availability_zones = ["us-east-1a", "us-east-1b"]
}

# Database
module "database" {
  source = "../../modules/database"
  
  environment           = var.environment
  vpc_id                = module.networking.vpc_id
  database_subnet_ids   = module.networking.database_subnet_ids
  app_security_group_id = module.compute.app_security_group_id
  
  instance_class  = "db.t3.micro"
  multi_az        = false  # Dev doesn't need multi-AZ
  master_username = var.db_master_username
  master_password = var.db_master_password
}

# Compute
module "compute" {
  source = "../../modules/compute"
  
  environment        = var.environment
  vpc_id             = module.networking.vpc_id
  public_subnet_ids  = module.networking.public_subnet_ids
  private_subnet_ids = module.networking.private_subnet_ids
  
  ami_id        = var.ami_id
  instance_type = "t3.micro"
  min_size      = 1
  max_size      = 3
  desired_capacity = 2
  
  vault_address = var.vault_address
  vault_token   = var.vault_token
  db_host       = module.database.address
  db_name       = "appdb"
}
```

**File: `environments/dev/variables.tf`**
```hcl
variable "aws_region" {
  description = "AWS region"
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name"
  default     = "dev"
}

variable "ami_id" {
  description = "AMI ID for EC2 instances"
  default     = "ami-0c55b159cbfafe1f0"  # Amazon Linux 2
}

variable "db_master_username" {
  description = "Database master username"
  type        = string
  sensitive   = true
}

variable "db_master_password" {
  description = "Database master password"
  type        = string
  sensitive   = true
}

variable "vault_address" {
  description = "Vault server address"
  default     = "http://YOUR_VAULT_IP:8200"
}

variable "vault_token" {
  description = "Vault token for app"
  type        = string
  sensitive   = true
}
```

**File: `environments/dev/terraform.tfvars`**
```hcl
aws_region          = "us-east-1"
environment         = "dev"
db_master_username  = "admin"
db_master_password  = "ChangeMe123!"  # Use Vault in production!
vault_address       = "http://127.0.0.1:8200"
vault_token         = "YOUR_VAULT_TOKEN"
```

**File: `environments/dev/outputs.tf`**
```hcl
output "alb_dns_name" {
  description = "DNS name of the load balancer"
  value       = module.compute.alb_dns_name
}

output "db_endpoint" {
  description = "Database endpoint"
  value       = module.database.endpoint
  sensitive   = true
}
```

---

## Phase 6: Deploy & Test (30 minutes)

### Deployment Steps

```bash
cd environments/dev

# Initialize Terraform
terraform init

# Review plan
terraform plan

# Apply (this will take 10-15 minutes)
terraform apply

# Note the ALB DNS name from output
```

### Testing

```bash
# Test health endpoint
curl http://<ALB_DNS_NAME>/health

# Test app
curl http://<ALB_DNS_NAME>/

# Test database connection (with Vault creds!)
curl http://<ALB_DNS_NAME>/db-test
```

---

## Phase 7: Create Architecture Diagram (30 minutes)

**Use draw.io or similar to create:**

1. **Network Diagram**
   - VPC with CIDR
   - Public/private/database subnets
   - Internet Gateway
   - NAT Gateways
   - Route tables

2. **Application Flow**
   - User → ALB → App instances → RDS
   - Show Vault integration

3. **Security Diagram**
   - Security groups
   - IAM roles
   - Vault authentication flow

**Save diagrams as PNG/PDF for interview discussion**

---

## Bonus Challenges

### Challenge 1: Add Monitoring
```hcl
# Add CloudWatch dashboard
resource "aws_cloudwatch_dashboard" "main" {
  dashboard_name = "${var.environment}-dashboard"
  
  dashboard_body = jsonencode({
    widgets = [
      {
        type = "metric"
        properties = {
          metrics = [
            ["AWS/ApplicationELB", "TargetResponseTime", {stat = "Average"}],
            [".", "RequestCount", {stat = "Sum"}]
          ]
          period = 300
          region = var.aws_region
          title  = "Application Metrics"
        }
      }
    ]
  })
}
```

### Challenge 2: Implement Blue/Green Deployment
```hcl
# Create second target group
# Switch ALB listener between blue/green
```

### Challenge 3: Add Sentinel Policy
```hcl
# Using Terraform Cloud
# Create policy that enforces:
# - All resources must have Owner tag
# - RDS must be encrypted
# - No t2.nano instances allowed
```

### Challenge 4: Multi-Environment
```bash
# Copy dev to prod
cp -r environments/dev environments/prod

# Modify for production:
# - multi_az = true
# - larger instance types
# - stricter security groups
# - remote state backend
```

---

## Interview Talking Points from This Project

### Technical Accomplishments
✓ "I built a production-like 3-tier application with Terraform"
✓ "Integrated HashiCorp Vault for dynamic database credentials"
✓ "Implemented auto-scaling with health checks"
✓ "Used modules for reusability across environments"
✓ "Configured multi-AZ deployment for high availability"

### Architecture Decisions
✓ "Why I chose Application Load Balancer over Network Load Balancer"
✓ "NAT Gateway design for private subnet internet access"
✓ "Security group design following least privilege"
✓ "Vault's transit engine for encryption at rest"

### Challenges & Solutions
✓ "Initial challenge with Vault agent configuration → solved with..."
✓ "Debugging auto-scaling health checks → learned about..."
✓ "State management considerations → decided to..."

### Real-World Applications
✓ "This architecture scales to enterprise needs by..."
✓ "For a client in [industry], I'd modify this by..."
✓ "The Vault integration solves compliance requirements for..."

---

## Cleanup (Important!)

```bash
# Destroy resources to avoid charges
cd environments/dev
terraform destroy

# Verify in AWS console that all resources are gone
```

---

## Study Tips

1. **Practice explaining**: Walk through each resource and why it's needed
2. **Draw it out**: Recreate architecture diagrams without looking
3. **Break something**: Delete a resource, see what breaks, fix it
4. **Explain to someone**: Teaching solidifies understanding
5. **Modify it**: Change CIDR blocks, add a resource, adjust security groups

---

## Additional Resources

- **Terraform Registry**: registry.terraform.io (browse modules)
- **Vault Documentation**: vaultproject.io/docs
- **AWS Architecture Center**: aws.amazon.com/architecture
- **HashiCorp Learn**: learn.hashicorp.com

**Good luck with your project and the interview! 🚀**

