# Client Scenarios & Solution Architectures

## How to Approach Client Conversations

### The Solutions Engineer Role

**You are:**
- Technical advisor to the sales team
- Bridge between sales and customer's technical team
- Solution architect and product expert
- Trusted advisor on best practices

**You are NOT:**
- Just a pre-sales demo person
- Implementation consultant (though you guide implementation)
- Sales closer (but you enable the sale)

### Discovery Framework (SPIN Selling)

**Situation:** Understand current state
- "Walk me through your current infrastructure provisioning process"
- "What tools are you using today?"
- "How is your infrastructure documented?"

**Problem:** Uncover pain points
- "What challenges are you facing?"
- "How much time does X take?"
- "What happens when something goes wrong?"

**Implication:** Make the pain real
- "How does this affect your time to market?"
- "What's the business impact of these delays?"
- "How many people are involved in this process?"

**Need-Payoff:** Show the value
- "What would it mean if you could provision in minutes instead of weeks?"
- "How would automatic compliance checks help your audit process?"
- "What could your team focus on if this was automated?"

---

## Scenario 1: Financial Services - Compliance & Security

### Client Background
**Company:** Regional bank, 500 employees, heavily regulated
**Current State:**
- Manual infrastructure provisioning
- Long-lived credentials shared across teams
- No audit trail for infrastructure changes
- Failed recent SOC 2 audit

**Pain Points:**
- "We failed our audit because we couldn't prove who changed what in production"
- "Our database passwords haven't been rotated in years"
- "It takes 3 weeks to provision a new environment for testing"
- "We have AWS credentials in Slack messages"

### Discovery Questions

**Your Questions:**
1. "What were the specific audit findings around infrastructure?"
2. "How do you currently manage secrets and credentials?"
3. "Tell me about your change management process"
4. "What compliance frameworks do you need to meet?" (PCI-DSS, SOC 2, etc.)
5. "How do you prove who accessed what and when?"

### HashiCorp Solution Architecture

**Phase 1: Terraform for IaC (Months 1-3)**

**Problem Solved:** No audit trail, inconsistent environments

```
Terraform Cloud/Enterprise
├── Workspaces per environment (dev, staging, prod)
├── VCS integration (Git = source of truth)
├── Audit logs (every plan/apply logged)
├── Sentinel policies (compliance checks)
└── Cost estimation (before provisioning)
```

**Implementation:**
1. Start with non-production environments
2. Define VPC, networking, compute as Terraform modules
3. Implement Sentinel policies:
   - Enforce encryption at rest
   - Require specific tags (Owner, CostCenter, Compliance)
   - Prevent public S3 buckets
   - Ensure multi-AZ deployment

**Example Sentinel Policy:**
```hcl
import "tfplan/v2" as tfplan

# All S3 buckets must have encryption
main = rule {
  all tfplan.resource_changes as _, rc {
    rc.type is "aws_s3_bucket" implies
      rc.change.after.server_side_encryption_configuration is not null
  }
}
```

**Business Value:**
- ✓ Complete audit trail (Git + Terraform Cloud logs)
- ✓ Automated compliance checks (prevent violations before deployment)
- ✓ Consistent environments (dev matches prod)
- ✓ 90% faster environment provisioning

**Phase 2: Vault for Secrets Management (Months 2-4)**

**Problem Solved:** Credential sprawl, no rotation, shared passwords

```
HashiCorp Vault (HA Cluster)
├── Database Secrets Engine
│   ├── Dynamic PostgreSQL credentials (1-hour TTL)
│   ├── Dynamic MySQL credentials
│   └── Automatic revocation
├── AWS Secrets Engine
│   └── Dynamic IAM credentials
├── Transit Engine
│   └── Encryption for PII data
└── Audit Logging
    └── Every secret access logged
```

**Implementation:**
1. Deploy Vault HA cluster (3 nodes, auto-unseal with AWS KMS)
2. Enable database secrets engine
3. Configure roles for different access levels:
   - `readonly`: SELECT only, 1-hour TTL
   - `app-write`: INSERT/UPDATE, 2-hour TTL
   - `admin`: Full access, 30-minute TTL

**Example Flow:**
```
Developer needs DB access
→ Authenticates to Vault (LDAP/OIDC)
→ Requests credentials: vault read database/creds/readonly
→ Vault creates temp PostgreSQL user (expires in 1 hour)
→ Developer connects with unique credentials
→ After 1 hour, Vault automatically revokes user
→ Complete audit trail: who accessed when
```

**Business Value:**
- ✓ No more shared database passwords
- ✓ Automatic credential rotation
- ✓ Complete audit trail (pass SOC 2)
- ✓ Reduced blast radius (compromised creds expire quickly)
- ✓ Individual accountability

**Phase 3: Integration & Optimization (Months 5-6)**

**Terraform + Vault Integration:**
```hcl
# Terraform retrieves secrets from Vault
data "vault_generic_secret" "db_admin" {
  path = "secret/terraform/db-admin"
}

resource "vault_database_secrets_mount" "postgres" {
  path = "database"
  
  postgresql {
    connection_url = "postgresql://{{username}}:{{password}}@postgres:5432/"
    username = data.vault_generic_secret.db_admin.data["username"]
    password = data.vault_generic_secret.db_admin.data["password"]
  }
}
```

**Complete Architecture:**
```
┌─────────────────────────────────────────┐
│         Terraform Cloud                  │
│  ┌────────────────────────────────┐    │
│  │  Sentinel Policies             │    │
│  │  - Encryption required         │    │
│  │  - Multi-AZ enforcement        │    │
│  │  - Tagging compliance          │    │
│  └────────────────────────────────┘    │
│                 │                        │
│                 ▼                        │
│  ┌────────────────────────────────┐    │
│  │  Terraform State (encrypted)    │    │
│  └────────────────────────────────┘    │
└─────────────────────────────────────────┘
                 │
                 │ (provisions)
                 ▼
┌─────────────────────────────────────────┐
│           AWS Infrastructure             │
│                                          │
│  ┌──────────┐      ┌──────────┐        │
│  │   VPC    │      │  RDS DB  │        │
│  │ Multi-AZ │      │ Encrypted│        │
│  └──────────┘      └──────────┘        │
└─────────────────────────────────────────┘
                 │
                 │ (gets creds from)
                 ▼
┌─────────────────────────────────────────┐
│         HashiCorp Vault                  │
│  ┌────────────────────────────────┐    │
│  │  Database Secrets Engine        │    │
│  │  - Dynamic credentials          │    │
│  │  - Auto rotation & revocation   │    │
│  └────────────────────────────────┘    │
│  ┌────────────────────────────────┐    │
│  │  Audit Logs                     │    │
│  │  - Who accessed what            │    │
│  │  - When and from where          │    │
│  └────────────────────────────────┘    │
└─────────────────────────────────────────┘
```

### ROI Calculation

**Before HashiCorp:**
- Environment provisioning: 3 weeks
- Manual change documentation: 8 hours/week
- Failed audit: $50K remediation cost
- Security incident risk: High

**After HashiCorp:**
- Environment provisioning: 2 hours
- Automatic audit trail: 0 hours/week
- Next audit: Pass
- Security posture: Dramatically improved

**Annual Savings:**
- Time savings: ~$200K (reduced manual work)
- Avoided audit failures: $50K+
- Reduced security incidents: Priceless
- Faster time to market: Competitive advantage

**Investment:**
- Terraform Enterprise: ~$60K/year
- Vault Enterprise: ~$80K/year
- Implementation: ~$100K (services)
- **Total: ~$240K first year, ~$140K/year ongoing**

**Payback Period:** 6-9 months

---

## Scenario 2: Healthcare - Multi-Cloud & HIPAA

### Client Background
**Company:** Healthcare SaaS, 200 employees, growing rapidly
**Current State:**
- AWS for primary workloads
- Azure for client-mandated deployments
- GCP for ML/AI workloads
- Each cloud managed differently

**Pain Points:**
- "Every cloud provider has different tools - it's chaos"
- "We can't easily replicate infrastructure across clouds"
- "HIPAA compliance is manual and error-prone"
- "Our ML team can't provision their own infrastructure"

### HashiCorp Solution

**Multi-Cloud Terraform Architecture:**

```hcl
# Unified codebase, multiple providers
terraform {
  required_providers {
    aws   = { source = "hashicorp/aws" }
    azurerm = { source = "hashicorp/azurerm" }
    google  = { source = "hashicorp/google" }
  }
}

# Shared module for 3-tier app
module "app_infrastructure" {
  source = "./modules/three-tier-app"
  
  # Works across all clouds with provider-agnostic abstraction
  cloud_provider = var.cloud_provider
  environment    = var.environment
  
  # HIPAA-compliant configurations enforced
  enable_encryption = true
  enable_logging    = true
  enable_monitoring = true
}
```

**Module Structure:**
```
modules/
├── network/
│   ├── aws/      # AWS VPC implementation
│   ├── azure/    # Azure VNet implementation
│   └── gcp/      # GCP VPC implementation
├── compute/
│   ├── aws/      # EC2, ECS, EKS
│   ├── azure/    # VMs, AKS
│   └── gcp/      # Compute Engine, GKE
└── database/
    ├── aws/      # RDS
    ├── azure/    # Azure SQL
    └── gcp/      # Cloud SQL
```

**HIPAA Compliance via Sentinel:**
```hcl
import "tfplan/v2" as tfplan

# Enforce encryption at rest (HIPAA requirement)
encrypt_at_rest = rule {
  all tfplan.resource_changes as _, rc {
    rc.type in ["aws_rds_instance", "azurerm_sql_database", "google_sql_database_instance"] implies
      rc.change.after.encrypted is true
  }
}

# Enforce audit logging (HIPAA requirement)
audit_logging = rule {
  all tfplan.resource_changes as _, rc {
    rc.type in ["aws_s3_bucket", "azurerm_storage_account", "google_storage_bucket"] implies
      rc.change.after.logging is not null
  }
}

# Enforce BAA-compliant tagging
hipaa_tagging = rule {
  all tfplan.resource_changes as _, rc {
    rc.change.after.tags contains "HIPAA-Scope" and
    rc.change.after.tags contains "PHI-Data"
  }
}

main = encrypt_at_rest and audit_logging and hipaa_tagging
```

**Self-Service for ML Team:**
```hcl
# ML workspace module
module "ml_workspace" {
  source = "./modules/ml-workspace"
  
  # Pre-approved configuration
  instance_type     = "n1-standard-8"
  gpu_type          = "nvidia-tesla-t4"
  storage_size_gb   = 500
  
  # Automatic compliance
  hipaa_compliant   = true
  
  # Cost controls
  max_monthly_cost  = 5000
  auto_shutdown     = true
}
```

**Business Value:**
- ✓ Single IaC platform across all clouds
- ✓ Automated HIPAA compliance
- ✓ Self-service infrastructure (ML team)
- ✓ Consistent security posture
- ✓ Easy to add new clouds

**Vault for PHI Encryption:**
```
Application
    │
    ├─ Stores PHI in database
    │     │
    │     └─ But encrypts via Vault first
    │
    ▼
Vault Transit Engine
    │
    ├─ Application sends: "John Doe, SSN 123-45-6789"
    │
    ├─ Vault returns: "vault:v1:abc123xyz..."
    │
    └─ Database stores ciphertext only
```

**Benefits:**
- PHI never stored in plaintext
- Centralized key management
- Key rotation without data migration
- Audit every encrypt/decrypt operation

---

## Scenario 3: E-commerce - Scale & Performance

### Client Background
**Company:** Fast-growing e-commerce, 50 engineers
**Current State:**
- Monolithic application
- Manual scaling during Black Friday
- Infrastructure team is bottleneck
- Frequent outages during traffic spikes

**Pain Points:**
- "Black Friday requires all-hands-on-deck for scaling"
- "Developers wait days for infrastructure changes"
- "We've had outages during our biggest sales days"
- "No consistent dev/staging environments"

### HashiCorp Solution

**Auto-Scaling Infrastructure:**

```hcl
# Auto-scaling web tier
resource "aws_autoscaling_group" "web" {
  min_size         = 5
  max_size         = 100
  desired_capacity = 10
  
  # Scale based on metrics
  target_group_arns = [aws_lb_target_group.web.arn]
  
  health_check_type         = "ELB"
  health_check_grace_period = 300
  
  launch_template {
    id      = aws_launch_template.web.id
    version = "$Latest"
  }
}

# Scale-up policy
resource "aws_autoscaling_policy" "scale_up" {
  name                   = "scale-up"
  autoscaling_group_name = aws_autoscaling_group.web.name
  
  policy_type = "TargetTrackingScaling"
  
  target_tracking_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ASGAverageCPUUtilization"
    }
    target_value = 70.0
  }
}

# Database read replicas for scale
resource "aws_db_instance" "read_replica" {
  count                = var.read_replica_count
  replicate_source_db  = aws_db_instance.primary.identifier
  instance_class       = "db.r5.xlarge"
  publicly_accessible  = false
}
```

**Self-Service Infrastructure Platform:**

```hcl
# Terraform Cloud with VCS integration
# Developers create PR with infrastructure changes
# Automatic terraform plan runs
# Engineering manager approves
# terraform apply runs automatically
# Infrastructure provisioned in minutes
```

**Pre-Production Environments:**

```hcl
# Each feature branch gets own environment
module "feature_environment" {
  source = "./modules/full-stack"
  
  environment     = "feature-${var.branch_name}"
  instance_count  = 2  # Smaller than prod
  database_size   = "db.t3.small"
  
  # Automatic cleanup after 7 days
  ttl_days = 7
}
```

**Architecture Diagram:**

```
                 ┌──────────────────┐
                 │  Route 53 DNS    │
                 │  Health Checks   │
                 └────────┬─────────┘
                          │
                          ▼
                 ┌──────────────────┐
                 │  CloudFront CDN  │
                 │  (Static Assets) │
                 └────────┬─────────┘
                          │
                          ▼
              ┌──────────────────────┐
              │  Application Load    │
              │  Balancer (Multi-AZ) │
              └──────────┬───────────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
    ┌────────┐     ┌────────┐     ┌────────┐
    │  ASG   │     │  ASG   │     │  ASG   │
    │  AZ-a  │     │  AZ-b  │     │  AZ-c  │
    │ 5-35   │     │ 5-35   │     │ 5-35   │
    │ nodes  │     │ nodes  │     │ nodes  │
    └───┬────┘     └────┬───┘     └───┬────┘
        │               │               │
        └───────────────┼───────────────┘
                        │
                        ▼
              ┌───────────────────┐
              │  ElastiCache       │
              │  (Redis Cluster)   │
              └────────┬──────────┘
                       │
                       ▼
         ┌─────────────────────────┐
         │  RDS Multi-AZ           │
         │  Primary + 2 Replicas   │
         │  (Read/Write Split)     │
         └─────────────────────────┘
```

**Terraform Automation:**
- All infrastructure as code
- Auto-scaling based on metrics
- Blue/green deployments
- Automatic rollback on failure

**Results:**
- **Provisioning time:** 2 weeks → 30 minutes
- **Black Friday:** Zero downtime, automatic scaling
- **Developer velocity:** 3x faster
- **Infrastructure costs:** 30% reduction (right-sizing + auto-scaling)

---

## Scenario 4: Startup - Speed & Agility

### Client Background
**Company:** Early-stage startup, 15 engineers, Series A funding
**Current State:**
- ClickOps (manual console management)
- No documentation of infrastructure
- Founder's AWS account
- Moving fast, breaking things

**Pain Points:**
- "We don't know what we have deployed"
- "Onboarding new engineers takes forever"
- "We're afraid to change anything in production"
- "Our staging environment is nothing like prod"

### HashiCorp Solution

**Quick Win Strategy:**

**Week 1: Terraform Cloud Setup**
```
1. Create Terraform Cloud organization
2. Import existing resources (terraform import)
3. Connect GitHub repo
4. Create dev/staging/prod workspaces
```

**Week 2: Standardize with Modules**
```
modules/
├── app-service/
│   ├── Load balancer
│   ├── Auto-scaling group
│   ├── Security groups
│   └── CloudWatch alarms
└── database/
    ├── RDS instance
    ├── Read replicas
    ├── Backup configuration
    └── Parameter groups
```

**Week 3: Implement CI/CD**
```
GitHub PR → Terraform plan runs
         → Shows what will change
         → Team reviews
         → Merge PR → Auto-apply
```

**Startup-Friendly Architecture:**

```hcl
# Start simple, scale later
module "mvp_infrastructure" {
  source = "./modules/startup-stack"
  
  # Minimal but production-ready
  app_instances     = 2
  database_size     = "db.t3.small"
  enable_monitoring = true
  enable_backups    = true
  
  # Easy to scale up
  auto_scaling      = true
  max_instances     = 10
}
```

**Cost Management:**
```hcl
# Terraform Cloud cost estimation
# See cost before applying

# Automatic shutdown of dev/staging at night
resource "aws_autoscaling_schedule" "night_shutdown" {
  scheduled_action_name  = "shutdown"
  min_size               = 0
  max_size               = 0
  desired_capacity       = 0
  recurrence             = "0 22 * * *"  # 10 PM
  autoscaling_group_name = aws_autoscaling_group.dev.name
  
  count = var.environment == "dev" ? 1 : 0
}
```

**Business Value:**
- ✓ Infrastructure documented as code
- ✓ Dev/staging/prod consistency
- ✓ Fast, safe changes
- ✓ 40% cost reduction (auto-shutdown, right-sizing)
- ✓ New engineer onboarding: 1 day instead of 1 week

**Pricing Model:**
- Terraform Cloud Free tier (up to 5 users)
- Pay-as-you-grow
- No upfront commitment

---

## Objection Handling

### "We're already using [competitor]"

**CloudFormation:**
"CloudFormation is great for AWS-only. But I see you're using Azure for your DR site and evaluating GCP for ML. Terraform gives you a single workflow across all clouds, so your team learns one tool instead of three. Plus, the Terraform module ecosystem is much larger - 3,000+ providers vs CloudFormation's AWS-only."

**Azure Resource Manager:**
"ARM templates work well for Azure. But when you need to provision across AWS and Azure together - like your hybrid setup - you need multiple tools and skillsets. Terraform provides a unified approach, and the HCL language is more readable than JSON. Would it help to see a side-by-side comparison?"

**Pulumi:**
"Pulumi is innovative with its code-first approach. The key difference is that Terraform's declarative model makes it easier to understand the desired end state, which is crucial for compliance and drift detection. Also, Terraform has 10+ years of production hardening and the largest community. That said, they're not mutually exclusive - some teams use both."

### "We don't have budget for Enterprise"

**Response:**
"I completely understand. The good news is Terraform and Vault are open source - you can start there at zero cost. Many companies run open source in production successfully.

However, let me show you what Enterprise adds and you can decide if the ROI makes sense:

For Terraform:
- **Sentinel policies** could prevent the security incident that cost you $500K last year
- **Private module registry** reduces your implementation time by 40%
- **Cost estimation** has helped similar clients reduce AWS spend by 20%

For Vault:
- **Namespaces** eliminate the need for multiple Vault clusters
- **DR replication** meets your RTO requirements
- **24/7 support** with SLAs

Would it be helpful to do a cost-benefit analysis based on your specific situation?"

### "This is too complex for our team"

**Response:**
"I hear that concern often, and it's valid - infrastructure can be complex. But here's the thing: the complexity exists whether you use Terraform or not. The question is whether that complexity is hidden (manual process, tribal knowledge) or explicit (code that documents itself).

Let me show you how we make it simple:
1. **Private module registry** - Your team uses pre-built, tested modules, not raw Terraform
2. **Policy as code** - Guardrails prevent mistakes
3. **Training** - We have free learning resources and can provide team training
4. **Start small** - Begin with one non-critical app, build confidence

Plus, Terraform Cloud has a GUI for approvals, so not everyone needs to know HCL.

What if we did a pilot with your team's least critical application? You can see firsthand how it works."

### "We're concerned about lock-in"

**Response:**
"Great question - vendor lock-in is a real concern. Here's why Terraform actually reduces lock-in:

**Open source:** Terraform core is open source. Your code is portable.

**Multi-cloud:** Unlike CloudFormation or ARM, Terraform works across all clouds. In fact, we help you avoid *cloud* vendor lock-in.

**State portability:** Your state files are yours. If you ever left Terraform, you still have full documentation of your infrastructure.

**Standard HCL:** The language is open and well-documented.

The real lock-in risk is with the clouds themselves - once you're on AWS, moving to Azure is hard regardless of the tool. Terraform makes multi-cloud easier, not harder."

---

## Discovery Question Bank

### Infrastructure & Operations
1. "Walk me through how you provision a new environment today"
2. "How long does it take from request to deployed?"
3. "Who can make infrastructure changes in production?"
4. "How do you document your infrastructure?"
5. "What happens when someone leaves who knows how things are configured?"
6. "How do you ensure dev/staging matches production?"

### Security & Compliance
1. "What compliance frameworks do you need to meet?"
2. "How do you manage secrets and credentials today?"
3. "When was the last time your database passwords were rotated?"
4. "Do you have an audit trail of infrastructure changes?"
5. "What would happen if an engineer's laptop was compromised?"
6. "How do you handle security incidents?"

### Scale & Performance
1. "Tell me about your busiest day/time of year"
2. "How do you handle traffic spikes?"
3. "Have you experienced outages? What caused them?"
4. "How quickly can you scale up/down?"
5. "What's your disaster recovery plan?"

### Team & Process
1. "How many people touch production infrastructure?"
2. "What's your change management process?"
3. "How do developers get the infrastructure they need?"
4. "What's your team's biggest bottleneck?"
5. "How do you onboard new engineers?"

### Business Impact
1. "What would faster infrastructure provisioning enable?"
2. "What does downtime cost your business?"
3. "What keeps you up at night about your infrastructure?"
4. "What are your company's top 3 goals this year?"
5. "How does infrastructure relate to those goals?"

---

## Closing Techniques

### Trial Close
"Based on what you've shared, it sounds like Terraform could help you provision 10x faster and Vault could solve your credential management challenge. Does that align with your thinking?"

### Next Steps
"Here's what I'd recommend:
1. **This week:** I'll send you our architecture guide and pricing
2. **Next week:** Let's do a technical deep-dive with your team
3. **Following week:** We can scope a pilot project together

Does that timeline work for you?"

### Create Urgency (But Don't Pressure)
"I noticed you mentioned the upcoming audit in Q3. If we start a pilot next month, you'd have time to implement before the audit. Would that be valuable?"

---

## Key Takeaways for Interview

1. **Lead with business value, not features**
   - Don't: "Terraform has state management"
   - Do: "Terraform eliminates configuration drift, which caused your outage last quarter"

2. **Show, don't just tell**
   - Have diagrams ready
   - Reference similar customer success stories
   - Use concrete examples

3. **Listen more than you talk**
   - Understand their pain before prescribing
   - Ask clarifying questions
   - Tailor solution to their needs

4. **Be honest about limitations**
   - "Terraform is great for infrastructure but not application deployment"
   - "Vault has a learning curve, but we have training resources"

5. **Think ecosystem**
   - Terraform + Vault together
   - Integration with their existing tools
   - Long-term platform vision

6. **Follow up matters**
   - Send relevant resources
   - Answer outstanding questions
   - Keep momentum going

